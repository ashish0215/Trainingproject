import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormService } from '../Service/FormService';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-update-form',
  templateUrl: './update-form.component.html',
  styleUrls: ['./update-form.component.css']
})
export class UpdateFormComponent
implements OnInit {

  registerForm:FormGroup;
  draft:any={};
  myDate:any=Date();
  isEditMode:boolean=false;
  formId:number;
   constructor(private formBuilder:FormBuilder,private toastr:ToastrService,
    public QuestionService: FormService,private activeroute:ActivatedRoute,private datePipe: DatePipe,private router:Router,private myhttp:HttpClient)
  {
    this.myDate = this.datePipe.transform(this.myDate, 'yyyy-MM-dd');
  }

  ngOnInit(): void {

    this.addForm();
    var id=this.activeroute.snapshot.paramMap.get("formId")
    if(id!=null && id!=undefined)
    {
      this.getFormData(Number(id));
    }

  }

  getFormData(id:number)
  {

    this.QuestionService.getbyid(id).subscribe((result:any)=>
    {
      console.log("xyz");

      if(result!=null)
      {
      this.registerForm.patchValue({"formId":result[0].formId, "Title": result[0].title,"Description":result[0].description,"ClosedDate":result[0].closedDate,"PublishedDate":result[0].publishedDate});
      this.PatchCheckboxForms(result[0].questions.filter((x: { typeId: number; })=>x.typeId==2));
      this.PatchRadioForms(result[0].questions.filter((x: { typeId: number; })=>x.typeId==1));
      this.PathRatingForms(result[0].questions.filter((x: { typeId: number; })=>x.typeId==3));
      this.PatchRankingQuestionForm(result[0].questions.filter((x: { typeId: number; })=>x.typeId==4));
      this.PatchSingleLineForm(result[0].questions.filter((x: { typeId: number; })=>x.typeId==5));
      this.PathMultiLineForm(result[0].questions.filter((x: { typeId: number; })=>x.typeId==6));

      }
    });
  }

    PatchCheckboxForms(questions:any) {
      questions.forEach((data: { questionName: any; typeId: any; options: { option: any; }[]; })=>{
        if(data.options.length>0)
        {
        this.checkboxsQuestions.push(this.formBuilder.group(

          {
            questionName: [data.questionName, Validators.required],
            questionType: data.typeId,
            checkbox1: [data.options[0].option, Validators.required],
            checkbox2: [data.options[1].option, Validators.required],
            checkbox3: [data.options[2].option, Validators.required],
            checkbox4: [data.options[3].option, Validators.required],
            checkbox1Check:false,
            checkbox2Check:false,
            checkbox3Check:false,
            checkbox4Check:false
          }));
        }
      });

    }
    PatchRadioForms(questions:any)
    {
       questions.forEach((data:{questionName:any;typeId:any;options:{option:any;}[];})=>

       {
        if(data.options.length>0)
       {
        this.singleoptionsQuestion.push(this.formBuilder.group(
        {
          questionName: [data.questionName, Validators.required],
          questionType: data.typeId,
          radio1: [data.options[0].option, Validators.required],
          radio2: [data.options[1].option, Validators.required],
          radio3: [data.options[2].option, Validators.required],
          radio4: [data.options[3].option, Validators.required],
          radio1Check:false,
          radio2Check:false,
          radio3Check:false,
          radio4Check:false
        }));
      }
    });

    }
    PathRatingForms(questions:any)
    {
      questions.forEach((data:{questionName:any;typeId:any;options:{option:any;}[];})=>
      {this.ratingQuestions.push(this.formBuilder.group(

        {
          questionName: [data.questionName, Validators.required],
          questionType: data.typeId,
          rating1:[data.options[0].option, Validators.required],


        }));
    });
    }
    PatchRankingQuestionForm(questions:any)
    {
      questions.forEach((data:{questionName:any;typeId:any;options:{option:any;}[];})=>
      {this.rankingQuestions.push(this.formBuilder.group(

        {
          questionName: [data.questionName, Validators.required],
          questionType: data.typeId,
          ranking:[data,Validators.required]

        }));
    });
    }
    PatchSingleLineForm(questions:any)
    {
      questions.forEach((data:{questionName:any;typeId:any;options:{option:any;}[];})=>
      {this.singleLineQuestion.push(this.formBuilder.group(
        {
          questionName: [data.questionName, [Validators.required, Validators.minLength(20)]],
          questionType: data.typeId,

        }));
    });
    }
    PathMultiLineForm(questions:any)
    {
      questions.forEach((data:{questionName:any;typeId:any;options:{option:any;}[];})=>
      {this.multiquestion.push(this.formBuilder.group(
        {
          questionName: [data.questionName, Validators.required],
          questionType: data.typeId,


        }));
    });
    }



   result: any;

  ShowPublished()
  {
    this.toastr.success('Form is Published','Published');
  }
  ShowInfo()
  {
    this.toastr.success('Show the Draft Form','Draft Mode');
  }
  addForm()
  {
   console.log("abcc")
   this.registerForm = this.formBuilder.group({
    formId: [0,Validators.required],
    ClosedDate: [null,Validators.required],
    Title: ["",Validators.required],
    Description: ["",Validators.required],
    Submissions: new FormControl(1),
    PublishedDate: ["",Validators.required],
    Status: 1,
    singleoptionsQuestion: this.formBuilder.array([]),
    checkboxsQuestions: this.formBuilder.array([]),
    singleLineQuestion: this.formBuilder.array([]),
    multiquestion: this.formBuilder.array([]),
    ratingQuestions: this.formBuilder.array([]),
    rankingQuestions: this.formBuilder.array([]),
    singleOptions:this.formBuilder.array([]),
    Multipleoptions:this.formBuilder.array([])

  })};

  registerSubmitted()
  {
    console.log(this.registerForm.get("Title"));
  }
  get Title():FormControl
  {
    return this.registerForm.get("Title") as FormControl;
  }
  get Description():FormControl
  {
    return this.registerForm.get("Description") as FormControl;
  }
  get Submissions()
  {
    return this.registerForm.get("Submissions") as FormControl;
  }
  get PublishedDate()
  {
    return this.registerForm.get("PublishedDate") as FormControl
  }
  get singleoptionsQuestion() {

    return this.registerForm.get("singleoptionsQuestion") as FormArray;
  }
  get checkboxsQuestions() {
    return this.registerForm.get("checkboxsQuestions") as FormArray;
  }
  get singleLineQuestion() {
    return this.registerForm.get("singleLineQuestion") as FormArray;
  }
  get multiquestion() {
    return this.registerForm.get("multiquestion") as FormArray;
  }
  get ratingQuestions() {
    return this.registerForm.get("ratingQuestions") as FormArray;
  }
  get rankingQuestions() {
    return this.registerForm.get("rankingQuestions") as FormArray;
  }
  get singleOptions()
  {
    return this.registerForm.get("singleOptions") as FormArray;
  }
  get Multipleoptions()
  {
    return this.registerForm.get("Multipleoptions") as FormArray;
  }
  //////////////////////////////////////////////////////Single Option Type Question///////////////
  SingleOptionQuestionForm() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: [1],
        radio1: [null, Validators.required],
        radio2: [null, Validators.required],
        radio3: [null, Validators.required],
        radio4: [null, Validators.required],
        radio1Check:false,
        radio2Check:false,
        radio3Check:false,
        radio4Check:false
      }
    );
  }

  MultipleOptionsForm()
  {
    return this.formBuilder.group(
    {
    OptionName: [null,Validators.required],
    optionType:[2],
    checkbox1: [null, Validators.required],
    checkbox2: [null, Validators.required],
    checkbox3: [null, Validators.required],
    checkbox4: [null, Validators.required],

    });
  }
  AddNewMultipleoptions()
  {
    this.Multipleoptions.push(this.MultipleOptionsForm());
  }
  RemoveMultipleOptions(i:Required<number>)
  {
    this.Multipleoptions.removeAt(i);
  }
  addNewOptionTypeQuestion() {
    // ''option = true
    this.singleoptionsQuestion.push(this.SingleOptionQuestionForm());
  }
  removeOptionTypeQuestion(i: Required<number>) {
    this.singleoptionsQuestion.removeAt(i);
  }

  ////////////////////////////////////////////////////////// Multiquestion and Multioption Type Questions///////////////
  CheckboxForms() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: 2,
        checkbox1: [null, Validators.required],
        checkbox2: [null, Validators.required],
        checkbox3: [null, Validators.required],
        checkbox4: [null, Validators.required],
        checkbox1Check:false,
        checkbox2Check:false,
        checkbox3Check:false,
        checkbox4Check:false
      }
    );
  }
  addNewCheckBoxForm() {
    // this.checkoption = true
    this.checkboxsQuestions.push(this.CheckboxForms());
  }
  removeChekbox(i: Required<number>) {
    this.checkboxsQuestions.removeAt(i);
  }

  /////////////////////////////////////////////////////////////////Rating Type Questions///////////////////////////

  ratingQuestionsform() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: [3],
        rating1:['', Validators.required],

      }
    );
  }

  addNewRatingForm() {
    this.ratingQuestions.push(this.ratingQuestionsform())
  }
  removeRating(i: Required<number>) {
    this.ratingQuestions.removeAt(i);
  }
  //////////////////////////////////////////////////////Ranking Type Questions//////////////////////////////////

  rankingQuestionsform() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: [4],
        ranking:["",Validators.required]

      });
  }

  addNewRankingForm() {
    this.rankingQuestions.push(this.rankingQuestionsform())
  }
  removeRanking(i: Required<number>) {
    this.rankingQuestions.removeAt(i);
  }
  ////////////////////////////////////////////////////////// Single Line Comment Type Questions ///////////////////
  singleLineQues() {
    return this.formBuilder.group(
      {
        questionName: ['', [Validators.required]],
        questionType: [5],

      }
    )
  }

  addNewSingleQuestion() {
    this.singleLineQuestion.push(this.singleLineQues());
  }
  removeSinglForm(i: Required<number>) {
    this.singleLineQuestion.removeAt(i);
  }

  /////////////////////////////////////////////////////////////////Multiline Comment Type Questions////////////////

  mulitLineCommentForm() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: [6],

      }
    );
  }
  AddMultilineComment() {
    // this.multioption = true
    this.multiquestion.push(this.mulitLineCommentForm())
  }
  removeMultilineComment(i: Required<number>) {
    this.multiquestion.removeAt(i);
  }
  clickOnUntitle() {

    if (this.showformuntitled == false) {
      this.showformuntitled = true

    }
    else {

      this.showformuntitled = false
    }

  }
  showformuntitled: Boolean = true;
  openbtn: boolean = false;
  makeInput: boolean = false;
  buttonOnOF() {
    if (this.openbtn == false) {
      this.openbtn = true
    }
    else {
      this.openbtn = false
    }
  }

  selectedradio() {
    this.makeInput = true
    console.log("radio", '');
  }
  clickoncancle() {
    // window.location.reload();
    this.registerForm.reset();
  }
  onSubmit() {
    if (this.registerForm.valid) {
      const formId = this.registerForm.value.formId;

      if (!formId) {
        const formData = this.registerForm.getRawValue();
        const createFormData = this.createQuestiondata(formData);
        this.QuestionService.CreateFormdata(createFormData).subscribe(
          t => {
            console.log(t);
            this.toastr.success('Successfully Form Created!');
          },
          error => {
            console.log(error);
            this.toastr.error('Failed to create form. Please check the input data.');
          }
        );
        this.registerForm.reset();
      }
    } else {
      this.toastr.error('Form is Invalid');
    }
  }
  updateFormData(): void {
    if (this.registerForm.valid) {
      const formId = this.activeroute.snapshot.paramMap.get('formId');
      const updatedData = this.registerForm.value;

      const headers = new HttpHeaders().set('Content-Type', 'application/json');

      this.myhttp
        .put(`http://localhost:5153/Form/updateForm?id=${formId}`, updatedData, { headers, observe: 'response' })
        .subscribe(
          (response) => {
              this.toastr.success('Data updated successfully!');

          },
          (error) => {
            // Handle error
            console.error('Failed to update data:', error);
            this.toastr.error('Failed to update data. Please check the input data.');
          }
        );
    } else {
      console.log(this.registerForm.value);
      this.result = this.registerForm.getRawValue();
      this.toastr.success('Successfully Form Created!')
      const createFormData=this.CreateFormData(this.result);
      this.QuestionService.CreateFormdata(createFormData).subscribe(t => {
      console.log(t);

    })
    this.toastr.error('Form is invalid');
  }
  }
draftdata:any;
CreateFormData(formdata:any)
{
  const data = {
    title: formdata.Title,
    description: formdata.Description,
    submissions: 0,
    status: formdata.Status,
    questionDetailDTO: this.createQuestiondata(formdata)
  }
  console.log("abc",formdata)
  return data;

}

createQuestiondata(questionslist:any){
  var  abc:any[]=[];

  questionslist.checkboxsQuestions.forEach((element:any) => {
    const data ={
      typeId: element.questionType,
      answer: this.getMultiAns(element),
      questionName: element.questionName,
      optionDetailDTO: [
        {
          option: element.checkbox1
        },
        {
          option: element.checkbox2
        },
        {
          option: element.checkbox3
        },
        {
          option: element.checkbox4
        }
      ]
    }


    abc.push(data);
  });
  questionslist.singleoptionsQuestion.forEach((element:any) => {
    const data ={
      typeId: element.questionType,
      answer: this.getAns(element),
      questionName: element.questionName,
      optionDetailDTO: [
        {
          option: element.radio1
        },
        {
          option: element.radio2
        },
        {
          option: element.radio3
        },
        {
          option: element.radio4
        }
      ]
    }
    abc.push(data);
  });
  questionslist.singleLineQuestion.forEach((element:any) => {
    const data ={
      typeId: element.questionType,
      questionName: element.questionName,
    }
    abc.push(data);
  });
  questionslist.ratingQuestions.forEach((element:any) => {
    const data ={
      typeId: element.questionType,
      questionName: element.questionName,
      optionDetailDTO: [
        {
          option: element.si
        },
        {
          option: "2 star"
        },
        {
          option: "3 star"
        },
        {
          option: "4 star"
        },
        {
          option: "5 star"
        },
        {
          rating:element.rating1
        }

      ]
    }
    abc.push(data);
  });
  questionslist.rankingQuestions.forEach((element:any) => {
    const data ={
      typeId: element.questionType,
      questionName: element.questionName,
      ranking:element.ranking
    }
    abc.push(data);
  });
  questionslist.multiquestion.forEach((element: { questionName: any; }) => {
    const data ={
      typeId: 2,
      questionName: element.questionName,
    }
    abc.push(data);
  });
  return abc;
}
createOptionsData(OptionsList:any)
{
  var opt:any[]=[];
  OptionsList.o
}
CreateDraftForm()
{
  this.registerForm.patchValue({ Status:2});
  this.onSubmit();
  }
  AddDraft(draft:any)
  {
    this.registerForm.valueChanges.subscribe(data => {
      this.draftdata = data;
  })}
  checkboxClick(o:any,i:number)
  {
    if(i==1)
    {
      o.value.radio1Check=true;
      o.value.radio2Check=false;
      o.value.radio3Check=false;
      o.value.radio4Check=false;
    }
    else if(i==2)
    {
      o.value.radio2Check=true;
      o.value.radio1Check=false;
      o.value.radio3Check=false;
      o.value.radio4Check=false;
    }
    else if(i==3)
    {
      o.value.radio3Check=true;
      o.value.radio2Check=false;
      o.value.radio1Check=false;
      o.value.radio4Check=false;
    }
    else if(i==4)
    {
      o.value.radio4Check=true;
      o.value.radio2Check=false;
      o.value.radio3Check=false;
      o.value.radio1Check=false;
    }

  }
  getAns(element:any):string
  {
    if(element.radio1Check==undefined)
    {
      return "radio1Check";
    }
    else if(element.radio2Check==undefined)
    {
      return "radio2Check";
    }
    else if(element.radio3Check==undefined)
    {
      return "radio3Check";
    }
    else if(element.radio4Check==undefined)
    {
      return "radio4Check";
    }
    return "";
  }
  getMultiAns(element:any):string
  {
    if(element.checkbox1Check==true)
    {
      return "checkbox1Check";
    }
    else if(element.checkbox2Check==true)
    {
      return "checkbox2Check";
    }
    else if(element.checkbox3Check==true)
    {
      return "checkbox3Check";
    }
    else if(element.checkbox4Check==true)
    {
      return "checkbox4Check";
    }
    return "";
  }
  myFunction(){
    this.myDate=new Date();
    let latest_date =this.datePipe.transform(this.myDate, 'yyyy-MM-dd');
   }
   editForm()
   {
    this.isEditMode=true;
   }
 }
