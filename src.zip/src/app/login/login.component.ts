import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormService } from '../Service/FormService';
import { ToastrService } from 'ngx-toastr';
import { User } from '../User';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  registerForm:FormGroup
  FormData:any={};

  constructor(private formBuilder: FormBuilder,private formservice:FormService,private activeroute:ActivatedRoute , private router: Router,private toastr:ToastrService) {
  }
  ngOnInit() {
    this.CreateUser();
  }

  Form()
  {
    this.formservice.CreateFormdata(User).subscribe(result=>{
      this.FormData = result;
      console.log(this.FormData);

  });
}
CreateUser(){
     this.registerForm = this.formBuilder.group({
      userName: ["",Validators.required],
      Email:["",Validators.required]

    });
  }
    registerSubmitted()
    {
      console.log(this.registerForm.get("userName"));
    }

    get userName():FormControl
    {
      return this.registerForm.get("userName") as FormControl;
    }
    get  Email():FormControl
    {
      return this.registerForm.get("Email") as FormControl;
    }
    UserForm()
  {
    return this.formBuilder.group(
      {
        userName: [null, Validators.required],
        Email: [null, Validators.required]
      }
    )
  }

  CreateUserData(userData:any)
{
  const data = {
    userName: userData.userName,
    FormId: userData.FormId,
    Email:userData.Email
  }
  return data;
}
result:any
clickOnUntitle() {

  if (this.showformuntitled == false) {
    this.showformuntitled = true

  }
  else {

    this.showformuntitled = false
  }

}
showformuntitled: Boolean = true;
openbtn: boolean = false;
makeInput: boolean = false;
buttonOnOF() {
  if (this.openbtn == false) {
    this.openbtn = true
  }
  else {
    this.openbtn = false
  }
}
onSubmit()
{
  if (this.registerForm.valid) {
  debugger;
    console.log(this.registerForm.value);
    this.result = this.registerForm.getRawValue();
  this.toastr.success('Login Successfully!')
  const createFormData=this.CreateUserData(this.result);
  // this.router.navigate(['home']);
  this.formservice.CreateUser(createFormData).subscribe(t => {
    
    localStorage.setItem('userId', t);
    if (t>0) {
 
    this.router.navigate(['home']);

    }
    console.log(t);
  }, error => {
    console.log(error);
  });
  console.log(this.registerForm.value)
  this.FormData=Object.assign(this.FormData,this.registerForm.value)
  // localStorage.setItem('FormDate',JSON.stringify(this.FormData));
  this.registerForm.reset();
} else {
  this.toastr.error("Form is Invalid")
}
}



}


