import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeadersComponent } from './Header/headers/headers.component';
import { CreateFormComponent } from './Forms/create-form/create-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxStarRatingModule} from 'ngx-star-rating';

import { FormService } from './Service/FormService';
import { DatePipe } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { ResponseComponent } from './response/response.component';
import { PreviewComponent } from './preview/preview.component';
import { FormPreviewComponent } from './form-preview/form-preview.component';
import { UpdateFormComponent } from './update-form/update-form.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';

const MyRoute:Routes=[
  //RouteTable
  {path:'User',component:LoginComponent},
  {path:'home/CreateForm',component:CreateFormComponent},
  {path:'home/Preview',component:PreviewComponent},
  {path:'Response',component:ResponseComponent},
  {path:'Update/:formId',component:UpdateFormComponent},
  {path:'FormReview/:formId',component:FormPreviewComponent},
  {path:'header',component: HeadersComponent},
  {path:'home',component: HomeComponent},
  {path:'login',component: LoginComponent}


];
const Route:Routes=[]
@NgModule({
  declarations: [
    AppComponent,
    HeadersComponent,
    CreateFormComponent,
    
    ResponseComponent,
    PreviewComponent,
    FormPreviewComponent,
    UpdateFormComponent,
    LoginComponent,
    HomeComponent,
                   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxStarRatingModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    RouterModule.forRoot(MyRoute),
  ],
  providers: [FormService,DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
