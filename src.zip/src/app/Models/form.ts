export class formmodel {
    FormId: 0;
    Title: string;
    Description: string;
    Link: string;
    Submissions: number;
    PublishedDate: any;
    formStatus: number;
    ClosedDate: any;
}
export class questions {
    QuestionName: string;
    QuestionType: number;
}


export class options {

    optionID: number;
    option: string;
}
export interface UserAnswer {
  userData: {
    Answer: string[];
    quesId: number;
  };
  FormId: number; // Updated to accept number
  userId: number; // Updated to accept number
}



