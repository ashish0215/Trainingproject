import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private activeroute:ActivatedRoute,private router:Router ) 
  { }
  
  ngOnInit(): void {
    
    }
    title = 'FeedBackUI';
    isFormVisible: boolean = true;
    isPreviewVisible: boolean = false;
  
    showForm() {
      this.isFormVisible = true;
      this.isPreviewVisible = false;
    }
  
    showPreview() {
      this.isFormVisible = false;
      this.isPreviewVisible = true;
    }

}
