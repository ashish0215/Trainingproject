import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FormService } from 'src/app/Service/FormService';

@Component({
  selector: 'app-headers',
  templateUrl: './headers.component.html',
  styleUrls: ['./headers.component.css']
})
export class HeadersComponent implements OnInit {


    editform:FormGroup;
    myDate:any=Date();
    constructor(private formBuilder:FormBuilder,public QuestionService: FormService,private activeroute:ActivatedRoute,private datePipe: DatePipe,private router:Router)
    {
      this.myDate = this.datePipe.transform(this.myDate, 'yyyy-MM-dd');
    }
    ngOnInit(): void {
      this.editforms();
      // console.log(this.activeroute.params.id)
      // this.QuestionService.getbyid(this.activeroute.params.id).subscribe((result)=>{
      // }
      this.activeroute.params.subscribe(params => {
       const id = params['id']; // Access the 'id' property using square brackets
       console.log(id);
      });

    }

    editforms()
    {
      this.editform= this.formBuilder.group({
        ClosedDate: ["",Validators.required],
        Title: ["",Validators.required],
        Description: ["",Validators.required],
        Submissions: new FormControl(1),
        PublishedDate: ["",Validators.required],
        Status: 1,

    })};

    registerSubmitted()
    {
      console.log(this.editform.get("Title"));
    }
    get Title():FormControl
    {
      return this.editform.get("Title") as FormControl;
    }
    get Description():FormControl
    {
      return this.editform.get("Description") as FormControl;
    }
    get Submissions()
    {
      return this.editform.get("Submissions") as FormControl;
    }
    get PublishedDate()
    {
      return this.editform.get("PublishedDate") as FormControl
    }


   


    //////////////////////////////////////////////////////Single Option Type Question///////////////

  }



