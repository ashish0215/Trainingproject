import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserAnswer, formmodel } from '../Models/form';


@Injectable()
export class FormService
{

    formUrl:string='http://localhost:5153/Form/NewForm';
    formGeturl:string='http://localhost:5153/Form/get';
    formdeleteurl:string='http://localhost:5153/Form/delete?id=';
    formUpdateurl:string='http://localhost:5153/Form/updateForm?';
    forGetByIdUrl:string='http://localhost:5153/Form/getFormById/';
    QuesUrl:string='http://localhost:5153/api/Question/crete';
    AnsUrl:string='http://localhost:5153/UserResponse/Form/Questin/Answer';
    AnswerGetByIdUrl:string='http://localhost:5153/getAnswerById/';
    UserUrl:string='http://localhost:5153/User/create';
    QuestionGetByIdUrl:string='http://localhost:5153/api/Question/Option/Fetch';
    constructor(private myhttp:HttpClient) { }

    listForms:formmodel[]=[];
    formData:formmodel=new formmodel();
    CreateFormdata(obj:any):Observable<any>
    {
      return this.myhttp.post<any>(this.formUrl ,obj);
    }
    getAllforms():Observable<formmodel[]>
    {
      return this.myhttp.get<formmodel[]>(this.formGeturl);
    }
    deleteForm(formId:number):Observable<any>
    {
      return this.myhttp.delete(this.formdeleteurl + formId);
    }
    updateFormdata():Observable<any>
    {
      return this.myhttp.put(this.formUpdateurl + this.formData.FormId,this.formData);
    }
    updateData(id: number, updatedData: any) {
      const url = `${this.formUpdateurl}/${id}`;
      return this.myhttp.put(url, updatedData);
    }

    getbyid(id:number)
    {
      return this.myhttp.get(this.forGetByIdUrl+id);
    }
    CreateQuestion(obj:any):Observable<any>
    {
      return this.myhttp.post<any>(this.QuesUrl, obj);
    }
    CreateAnswer(userAnswerDetailDTO: any, quesId: number, userId: number, formId: number): Observable<number> {
      const obj = {
        userAnswerDetailDTO: userAnswerDetailDTO,
        quesId: quesId,
        userId: userId,
        formId: formId
      };
      return this.myhttp.post<number>(this.AnsUrl, obj);
    }

    getbyAnswerId(id:number)
    {
      return this.myhttp.get(this.AnswerGetByIdUrl+id);
    }
    CreateUser(obj:any):Observable<any>
    {
      return this.myhttp.post<any>(this.UserUrl, obj);
    }
    GetQuestionById(id:number)
    {
      return this.myhttp.get(this.QuestionGetByIdUrl+id);
    }
    postUserAnswer(userAnswer: any): Observable<any> {

      // Replace with the actual API URL where you want to post the data
      return this.myhttp.post<any>(this.AnsUrl, userAnswer);
    }


}
