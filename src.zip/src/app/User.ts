export class User {
  userName: string;
  Email: string;
  constructor(name: string, mail: string) {
    this.userName = name;
    this.Email = mail;

  }
}
