import { Component, OnInit, ViewChild } from '@angular/core';

import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { FormService } from '../Service/FormService';
import { formmodel } from '../Models/form';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css']
})
export class PreviewComponent implements OnInit {
  @ViewChild('CreateForm') CreateForm: NgForm
previewData:any;
  constructor(public formService: FormService, public datepipe: DatePipe,private tostr:ToastrService,private fbb:FormBuilder) { }
editMode:boolean=false;

  ngOnInit() {
    this.formService.getAllforms().subscribe(data => {
      this.previewData = data;
      // this.save = false;
      // console.log(this.save);

    })
  }
  userForm: FormGroup;
  createForm() {
    this.userForm = this.fbb.group({
        formId: [''],
        Description: ['', [Validators.required]],
        Title: ['', [Validators.required]],
        closed: ['', [Validators.required]]
    });
  }
  onEditForm(formId: number, index: number) {
    this.editMode=true;
    console.log(this.formService.listForms[index]);
  }
  users: any[] = [];
  save: any;
  uids:any;
  editUser(formId:number) {
    this.save = true;
    for (let i = 0; i < this.users.length; i++) {
      if (this.users[i].formId === formId) {
        console.log(this.users[i].formId);
        this.uids = this.users[i].formId;
        this.userForm.patchValue({
          formId: this.users[i].formId,
          Description: this.users[i].Description,
          Title: this.users[i].Title,
          PublishedDate: this.users[i].PublishedDate,
          closed: this.users[i].ClosedDate
        });
      }
    }
  }
  registrations: formmodel[] = [];
  regModel: formmodel;
  selectedRow:number;
  showNew:boolean=false
  submitType: string = "Save";

    onEdit(formId:number,index: number) {
    this.selectedRow = index;
    this.regModel = new formmodel();
    // Retrieve selected
    this.regModel = Object.assign({}, this.registrations[this.selectedRow]);
    this.submitType = 'Update';
    this.showNew = true;

  }

  async delete(formId: number) {
    console.log(formId);
    if (confirm('Are you really want to delete this record?'))
     {
       try {

        const response=await this.formService.deleteForm(formId).subscribe(data => {
          console.log(data);
          this.formService.getAllforms().subscribe(data => {
            console.log(data);
            this.formService.listForms = data;
            this.tostr.success("Record Deleted");;
            console.log('Sucess', 'Record Deleted');
          });
        },
          err => {
          });
        console.log(response);

       } catch (error) {
          console.log(error);
       }

  
    }
  }

}


