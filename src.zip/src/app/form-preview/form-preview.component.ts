import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { FormService } from '../Service/FormService';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { UserAnswer } from '../Models/form';

@Component({
  selector: 'app-form-preview',
  templateUrl: './form-preview.component.html',
  styleUrls: ['./form-preview.component.css']
})
export class FormPreviewComponent implements OnInit {

  questionForm: FormGroup;
  draft: any = {};
  questionAnsList: any = [];
  myDate: any = Date();
  index: number = 0;
  formId: any;
  quesId: number;
  userId: number;
  userAnswerValues: string[];
  constructor(private formBuilder: FormBuilder, private toastr: ToastrService,
    public QuestionService: FormService, private activeroute: ActivatedRoute, private datePipe: DatePipe, private router: Router, private myhttp: HttpClient) {
    this.myDate = this.datePipe.transform(this.myDate, 'yyyy-MM-dd');
  }

  ngOnInit(): void {

    this.questionsForm();
    this.userId=Number(localStorage.getItem('userId'));
    console.log(this.userId);
    var id=this.activeroute.snapshot.paramMap.get("formId")
    if(id!=null && id!=undefined)
    {
      this.formId=Number(id);
      this.getFormData(Number(id));
    }
    
  }

  getFormData(id: number) {
    this.QuestionService.getbyid(id).subscribe((result: any) => {
      this.PatchRadioForms(result[0].questions.filter((x: { typeId: number; }) => x.typeId == 1));
      this.PatchCheckboxForms(result[0].questions.filter((x: { typeId: number; }) => x.typeId == 2));
      this.questionForm.patchValue({ "Title": result[0].title, "Description": result[0].description, "ClosedData": result[0].closedDate });
      //this.questionForm.patchValue({"singleoptionsQuestion": singleOption});
      this.PathRatingForms(result[0].questions.filter((x: { typeId: number; }) => x.typeId == 3));
      this.PatchRankingQuestionForm(result[0].questions.filter((x: { typeId: number; }) => x.typeId == 4));
      this.PatchSingleLineForm(result[0].questions.filter((x: { typeId: number; }) => x.typeId == 5));
      this.PathMultiLineForm(result[0].questions.filter((x: { typeId: number; }) => x.typeId == 6));
    });
  }

  PatchCheckboxForms(questions: any): any {
    questions.forEach((data: { questionName: any; questId: any; typeId: any; options: { option: any; }[]; }) => {
      if (data.options.length > 0) {
        this.multioptionsQuestion.push(this.formBuilder.group({

          questionName: [data.questionName],
          typeId: [data.typeId],
          option1: [data.options[0].option],
          option2: [data.options[1].option],
          option3: [data.options[2].option],
          option4: [data.options[3].option],
          answer: [""],
          questionId: [data.questId],
          checkbox1Check: false,
          checkbox2Check: false,
          checkbox3Check: false,
          checkbox4Check: false
        }));

      }
    }
    );
    return this.questionAnsList;
  }
  PatchRadioForms(questions: any): any {
    questions.forEach((data: { questionName: any; questId: any; typeId: any; options: { option: any; }[]; }) => {
      if (data.options.length > 0) {
        this.singleoptionsQuestion.push(this.formBuilder.group({
          questionName: [data.questionName],
          typeId: [data.typeId],
          option1: [data.options[0].option],
          option2: [data.options[1].option],
          option3: [data.options[2].option],
          option4: [data.options[3].option],
          answer: [""],
          questionId: [data.questId],
          radio1Check: false,
          radio2Check: false,
          radio3Check: false,
          radio4Check: false
        }));
      }
    }
    );

  }

  PathRatingForms(questions: any) {
    questions.forEach((data: { questionName: any; questId: any; typeId: any; options: { option: any; }[]; }) => {

      this.ratingQuestions.push(this.formBuilder.group({
        questionName: [data.questionName],
        typeId: [data.typeId],
        answer: [""],
        questionId: [data.questId]
      }))
    }

    );

  }

  PatchRankingQuestionForm(questions: any) {
    questions.forEach((data: { questionName: any; questId: any; typeId: any; options: { option: any; }[]; }) => {

      this.rankingQuestion.push(this.formBuilder.group({
        questionName: [data.questionName],
        typeId: [data.typeId],
        answer: [""],
        questionId: [data.questId]
      }));


    }
    );

  }
  PatchSingleLineForm(questions: any) {
    questions.forEach((data: { questionName: any; questId: any; typeId: any; options: { option: any; }[]; }) => {

      this.singleLineQuestion.push(this.formBuilder.group({
        questionName: [data.questionName],
        typeId: [data.typeId],
        answer: [""],
        questionId: [data.questId]
      }));


    }
    );

  }
  PathMultiLineForm(questions: any) {
    questions.forEach((data: { questionName: any; questId: any; typeId: any; options: { option: any; }[]; }) => {
      this.multiLineQuestion.push(this.formBuilder.group({
        questionName: [data.questionName],
        typeId: [data.typeId],
        answer: [""],
        questionId: [data.questId]
      })
      );

    }
    );
  }



  result: any;
  
  ShowPublished() {
    this.toastr.success('Form is Published', 'Published');
  }
  ShowInfo() {
    this.toastr.success('Show the Draft Form', 'Draft Mode');
  }

  questionsForm() {
    console.log("abcc")
    this.questionForm = this.formBuilder.group({
      questionAns: this.formBuilder.array([]),
      singleoptionsQuestion: this.formBuilder.array([]),
      multioptionsQuestion: this.formBuilder.array([]),
      rankingQuestion: this.formBuilder.array([]),
      ratingQuestions: this.formBuilder.array([]),
      singleLineQuestion: this.formBuilder.array([]),
      multiLineQuestion: this.formBuilder.array([])

    })
  };


  //////////////////////////////////////////////////////Single Option Type Question///////////////
  SingleOptionQuestionForm() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: [1],
        radio1: [null, Validators.required],
        radio2: [null, Validators.required],
        radio3: [null, Validators.required],
        radio4: [null, Validators.required],
        radio1Check: false,
        radio2Check: false,
        radio3Check: false,
        radio4Check: false
      }
    );
  }


  ////////////////////////////////////////////////////////// Multiquestion and Multioption Type Questions///////////////
  CheckboxForms() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: 2,
        checkbox1: [null, Validators.required],
        checkbox2: [null, Validators.required],
        checkbox3: [null, Validators.required],
        checkbox4: [null, Validators.required],
        checkbox1Check: false,
        checkbox2Check: false,
        checkbox3Check: false,
        checkbox4Check: false
      }
    );
  }


  /////////////////////////////////////////////////////////////////Rating Type Questions///////////////////////////

  ratingQuestionsform() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: [3],
        rating1: ['', Validators.required],

      }
    );
  }


  //////////////////////////////////////////////////////Ranking Type Questions//////////////////////////////////

  rankingQuestionsform() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: [4],
        ranking: ["", Validators.required]

      });
  }


  ////////////////////////////////////////////////////////// Single Line Comment Type Questions ///////////////////
  singleLineQues() {
    return this.formBuilder.group(
      {
        questionName: ['', [Validators.required, Validators.minLength(20)]],
        questionType: [5],

      }
    )
  }



  /////////////////////////////////////////////////////////////////Multiline Comment Type Questions////////////////

  mulitLineCommentForm() {
    return this.formBuilder.group(
      {
        questionName: [null, Validators.required],
        questionType: [6],

      }
    );
  }

  clickOnUntitle() {

    if (this.showformuntitled == false) {
      this.showformuntitled = true

    }
    else {

      this.showformuntitled = false
    }

  }
  showformuntitled: Boolean = true;
  openbtn: boolean = false;
  makeInput: boolean = false;
  buttonOnOF() {
    if (this.openbtn == false) {
      this.openbtn = true
    }
    else {
      this.openbtn = false
    }
  }

  selectedradio() {
    this.makeInput = true
    console.log("radio", '');
  }
  clickoncancle() {
    // window.location.reload();
    this.questionForm.reset();
  }
  onSubmit() {


    // this.http.navigate(['']);
    // window.location.reload();

    if (this.questionForm.valid) {
      console.log(this.questionForm.value);
      this.result = this.questionForm.getRawValue();
      this.toastr.success('Successfully Form Created!')
      const createFormData = this.CreateFormData(this.result);
      this.QuestionService.CreateFormdata(createFormData).subscribe(t => {
        console.log(t);
      }, error => {
        console.log(error);
      });
      this.questionForm.reset();
    } else {
      this.toastr.error("Form is Invalid")
    }
  }
  // onClick() {
  //   if (this.questionForm.valid) {
  //     console.log(this.questionForm.value);
  //     const formData = this.createQuestionAnsData(this.questionForm.getRawValue());
  //     const formId = this.formId; // Assign the appropriate form ID

  //     this.QuestionService.CreateAnswerdata(formData, formId).subscribe(
  //       () => {
  //         console.log('Answer submitted successfully');
  //         this.toastr.success('Successfully Answer Submitted!');
  //         this.saveAnswerInDatabase(formData); // Save the answer in the database
  //       },
  //       (error: any) => {
  //         console.log(error);
  //         if (error.status === 0) {
  //           this.toastr.error('Failed to submit answer. Server is not reachable.');
  //         } else if (error.status === 400) {
  //           this.toastr.error('Failed to submit answer. Invalid request.');
  //         } else if (error.status === 203) {
  //           this.toastr.error('Failed to submit answer. Non-Authoritative Information.');
  //         } else {
  //           this.toastr.error('An error occurred while submitting the answer.');
  //         }
  //       }
  //     );

  //     this.questionForm.reset();
  //   } else {
  //     this.toastr.error('Form is Invalid');
  //   }
  // }

  // saveAnswerInDatabase(formData: any) {
  //   const userAnswerDetailDTO = {
  //     // Create the UserAnswerDetailDTO object based on your requirements
  //     // Assign the appropriate properties with the values from formData
  //     questionId: this.quesId,
  //     userId: this.userId,
  //     formId: this.formId,
  //     // ...
  //   };

  //   this.QuestionService.CreateAnswer(userAnswerDetailDTO,this.quesId,this.formId,this.userId).subscribe(
  //     () => {
  //       console.log('Answer saved in the database');
  //     },
  //     (error: any) => {
  //       console.log('Failed to save answer in the database:', error);
  //     }
  //   );
  // }
  postData() {
    const formData = this.createQuestionAnsData(this.questionForm.getRawValue());
    const userAnswer: UserAnswer = {
      userId: this.userId,
      FormId: this.quesId,
      userData: {
        Answer: this.userAnswerValues,
        quesId: this.quesId
      }
    };

    this.QuestionService.postUserAnswer(formData).subscribe(
      response => {
        // Handle the response from the backend server
        console.log(response);
        this.toastr.success('Successfully Answer Submitted!');
      },
      error => {
        // Handle errors if the request fails
        console.error(error);
      });
  }

  draftdata: any;
  CreateFormData(formdata: any) {
    const data = {
      title: formdata.Title,
      description: formdata.Description,
      submissions: 0,
      status: formdata.Status,
      questionDetailDTO: this.createQuestiondata(formdata)
    }
    console.log("abc", formdata)
    return data;

  }

  createQuestiondata(questionslist: any) {
    var abc: any[] = [];

    questionslist.multioptionsQuestion.forEach((element: any) => {
      const data = {
        typeId: element.questionType,
        answer: this.getMultiAns(element),
        questionName: element.questionName,
        optionDetailDTO: [
          {
            option: element.checkbox1
          },
          {
            option: element.checkbox2
          },
          {
            option: element.checkbox3
          },
          {
            option: element.checkbox4
          }
        ]
      }


      abc.push(data);
    });
    questionslist.singleoptionsQuestion.forEach((element: any) => {
      const data = {
        typeId: element.questionType,
        answer: this.getAns(element),
        questionName: element.questionName,
        optionDetailDTO: [
          {
            option: element.radio1
          },
          {
            option: element.radio2
          },
          {
            option: element.radio3
          },
          {
            option: element.radio4
          }
        ]
      }
      abc.push(data);
    });
    questionslist.singleLineQuestion.forEach((element: any) => {
      const data = {
        typeId: element.questionType,
        questionName: element.questionName,
      }
      abc.push(data);
    });
    questionslist.ratingQuestions.forEach((element: any) => {
      const data = {
        typeId: element.questionType,
        questionName: element.questionName,
        optionDetailDTO: [
          {
            option: element.si
          },
          {
            option: "2 star"
          },
          {
            option: "3 star"
          },
          {
            option: "4 star"
          },
          {
            option: "5 star"
          },
          {
            rating: element.rating1
          }

        ]
      }
      abc.push(data);
    });
    questionslist.rankingQuestions.forEach((element: any) => {
      const data = {
        typeId: element.questionType,
        questionName: element.questionName,
        ranking: element.ranking
      }
      abc.push(data);
    });
    questionslist.multiquestion.forEach((element: { questionName: any; }) => {
      const data = {
        typeId: 2,
        questionName: element.questionName,
      }
      abc.push(data);
    });
    return abc;
  }
  createOptionsData(OptionsList: any) {
    var opt: any[] = [];
    OptionsList.o
  }

  checkboxClick(o: any, i: number) {
    if (i == 1) {
      o.value.radio1Check = true;
      o.value.radio2Check = false;
      o.value.radio3Check = false;
      o.value.radio4Check = false;
    }
    else if (i == 2) {
      o.value.radio2Check = true;
      o.value.radio1Check = false;
      o.value.radio3Check = false;
      o.value.radio4Check = false;
    }
    else if (i == 3) {
      o.value.radio3Check = true;
      o.value.radio2Check = false;
      o.value.radio1Check = false;
      o.value.radio4Check = false;
    }
    else if (i == 4) {
      o.value.radio4Check = true;
      o.value.radio2Check = false;
      o.value.radio3Check = false;
      o.value.radio1Check = false;
    }

  }
  getAns(element: any): string {
    if (element.radio1Check == undefined) {
      return "radio1Check";
    }
    else if (element.radio2Check == undefined) {
      return "radio2Check";
    }
    else if (element.radio3Check == undefined) {
      return "radio3Check";
    }
    else if (element.radio4Check == undefined) {
      return "radio4Check";
    }
    return "";
  }
  getMultiAns(element: any): string {
    if (element.checkbox1Check == true) {
      return "checkbox1Check";
    }
    else if (element.checkbox2Check == true) {
      return "checkbox2Check";
    }
    else if (element.checkbox3Check == true) {
      return "checkbox3Check";
    }
    else if (element.checkbox4Check == true) {
      return "checkbox4Check";
    }
    return "";
  }
  get singleoptionsQuestion() {

    return this.questionForm.get("singleoptionsQuestion") as FormArray;
  }
  get multioptionsQuestion() {
    return this.questionForm.get("multioptionsQuestion") as FormArray;
  }
  get rankingQuestion() {
    return this.questionForm.get("rankingQuestion") as FormArray;
  }
  get ratingQuestions() {
    return this.questionForm.get("ratingQuestions") as FormArray;
  }
  get singleLineQuestion() {
    return this.questionForm.get("singleLineQuestion") as FormArray;
  }
  get multiLineQuestion() {
    return this.questionForm.get("multiLineQuestion") as FormArray;
  }
  getIndex(): number {
    return this.index++
  }

  // onClick() {
  //   if (this.questionForm.valid) {
  //     console.log(this.questionForm.value);
  //     this.result = this.questionForm.getRawValue();
  //     const createFormData = this.createQuestionAnsData(this.result);

  //     this.QuestionService.CreateAnswer(createFormData).subscribe(
  //       t => {
  //         console.log(t);
  //         this.toastr.success('Successfully Answer Submitted!');
  //       },
  //       error => {
  //         console.log(error);
  //       }
  //     );

  //     this.questionForm.reset();
  //   } else {
  //     this.toastr.error('Form is Invalid');
  //   }
  // }

  createQuestionAnsData(formdata: any) {
    const data = {
      formId: this.formId,
      userId:  this.userId=Number(localStorage.getItem('userId')),
      responce: this.CreateQuestiondata(formdata)
    }
    console.log("abc", formdata)
    return data;

  }

  CreateQuestiondata(questionslist: any) {
    var abc: any[] = [];

    questionslist.multioptionsQuestion.forEach((element: any) => {
      const data = {
        questionId: element.questionId,
        answer: this.getMultiAns(element),

      }


      abc.push(data);
    });
    questionslist.singleoptionsQuestion.forEach((element: any) => {
      const data = {
        questionId: element.questionId,
        answer: this.getAns(element),

      }
      abc.push(data);
    });
    questionslist.singleLineQuestion.forEach((element: any) => {
      const data = {
        questionId: element.questionId,
        answer: element.answer,
      }
      abc.push(data);
    });
    questionslist.ratingQuestions.forEach((element: any) => {
      const data = {
        questionId: element.questionId,
        answer: element.answer,
      }
      abc.push(data);
    });
    questionslist.rankingQuestion.forEach((element: any) => {
      const data = {
        questionId: element.questionId,
        answer: element.answer,
      }
      abc.push(data);
    });
    questionslist.multiLineQuestion.forEach((element: any) => {
      const data = {
        questionId: element.questionId,
        answer: element.answer,
      }
      abc.push(data);
    });
    return abc;
  }



  userAnswer = {
    userId: '',
    formId: 0,
    quesId: 0,
    answer: ['']
  };
}


