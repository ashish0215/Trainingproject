import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-response',
  templateUrl: './response.component.html',
  styleUrls: ['./response.component.css']
})
export class ResponseComponent implements OnInit {

  constructor(private formbuilder:FormBuilder)
  {

  }
  ngOnInit(): void {
    // throw new Error('Method not implemented.');
  }

   PublishedForm = this.formbuilder.group({
     Title:["",Validators.required],
     Submission: ["",Validators.required],
     PublishedDate: ["",Validators.required],
     ClosedDate: ["",Validators.required],
     Status: ["",Validators.required]
   });
   PublishedSubmitted()
   {
     console.log(this.PublishedForm.get("Submission"));
   }
   get Title():FormControl
   {
     return this. PublishedForm.get("Title") as FormControl;
   }
   get PublishedDate():FormControl
   {
     return this. PublishedForm.get("PublishedDate") as FormControl;
   }
   get ClosedDate():FormControl
   {
     return this.ClosedDate.get("ClosedDate") as FormControl;
   }
   get Status():FormControl
   {
     return this.PublishedForm.get("Status") as FormControl;
   }

}
