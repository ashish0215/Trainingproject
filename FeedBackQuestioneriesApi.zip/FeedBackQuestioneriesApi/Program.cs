using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Functionality;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Mapper.DTOValidation;
using FeedBackQuestioneriesApi.Mapper.DTO;
using FluentValidation;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

        builder.Services.AddDbContext<FeedbackFormDbContext>(t => t.UseNpgsql(builder.Configuration.GetConnectionString("myCon")));
        builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        builder.Services.AddTransient<IFormService, FormService>();
        builder.Services.AddScoped<IValidator<OptionsDTO>, OptionsValidation>();
        builder.Services.AddTransient<IOptionsService, OptionsService>();
        builder.Services.AddScoped<IValidator<QuestionTypeDTO>, QuestionTypeValidation>();
        builder.Services.AddTransient<IQuestionTypeService, QuestionTypeService>();
         builder.Services.AddScoped<IValidator<UserAnswerDto>,UserAnswerValidation>();
        builder.Services.AddTransient<IUserAnswer, UserAnswerService>();
        builder.Services.AddTransient<IUserResponseService, UserResponseservice>();
        builder.Services.AddTransient<IUserService, UserService>();
        builder.Services.AddScoped<IValidator<UserResponseDto>, UserResponsevalidation>();
        builder.Services.AddTransient<IQuestionService, QuestionService>();
        builder.Services.AddScoped<IValidator<QuestionsDTO>, QuestionValidation>();
        builder.Services.AddScoped<IValidator<UserDto>, UserValidation>();
        builder.Services.AddScoped<IValidator<FormDtO>, FormValidation>();
        builder.Services.AddCors(options =>{
        options.AddPolicy(name: "AllowOrign",builder=>
        {
           builder.WithOrigins("http://localhost:4200").AllowAnyHeader().AllowAnyOrigin()
                       .AllowAnyMethod();
        });
        });
        builder.Services.AddControllersWithViews().AddNewtonsoftJson(options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowOrign");
app.UseAuthorization();

app.MapControllers();

app.Run();
