using System.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using FeebackQuestionaireAPI.Mapper.DTO;

namespace FeebackQuestionaireAPI.Models.Entity
{
    public class UserResponse
    {
        [Key]
        public int UserRespId { get; set; }
        public int formId{get;set;}
        public int UserId { get; set; } //fk
        public Form Form{get;set;} //cascading
        public User Users { get; set; }  //cascading
         //public virtual Question Question{get;set;}
        public ICollection<UserAnswer> UserAnswers{get;set;} //navigation
        public UserResponse()
        {
            
        }
        public UserResponse(UserResponseDto userResponseDto)
        {
            UserRespId = userResponseDto.UserRespId;
            UserId = userResponseDto.UserId;
            formId = userResponseDto.FormId;
            
        }
    }
}