using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FeebackQuestionaireAPI.Models.EntityMapper
{
    public class OptionsMapper
    {
        public OptionsMapper(EntityTypeBuilder<Options> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(e=>e.OptionId);
            entityTypeBuilder.Property(e=>e.Option).IsRequired();
          //  entityTypeBuilder.HasOne(e=>e.Questions).WithMany(e=>e.Options).HasForeignKey(e=>e.QuestId).IsRequired();
        }
    }
}