using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FeebackQuestionaireAPI.Models.EntityMapper
{
    public class UserAnswerMapper
    {
        public UserAnswerMapper(EntityTypeBuilder<UserAnswer> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(e=>e.UserAnsId);
            //entityTypeBuilder.Property(e=>e.answer);
           // entityTypeBuilder.Property(e=>e.QuestionNo).IsRequired();
          //  entityTypeBuilder.HasOne(e=>e.UserResponse).WithMany(e=>e.UserAnswers).HasForeignKey(e=>e.UserRespId);
        }
    }
}