using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FeebackQuestionaireAPI.Models.EntityMapper
{
    public class FormMapper
    {
        public FormMapper(EntityTypeBuilder<Form> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(e=>e.FormId);
            entityTypeBuilder.Property(e=>e.Title).IsRequired();
            entityTypeBuilder.Property(e=>e.Description).IsRequired();
            entityTypeBuilder.Property(e=>e.Link).IsRequired();
            entityTypeBuilder.Property(e=>e.Submissions).IsRequired();
            entityTypeBuilder.Property(e=>e.PublishedDate).IsRequired();
            entityTypeBuilder.Property(e=>e.ClosedDate).IsRequired();
          //  entityTypeBuilder.HasMany(e=>e.Questions).WithOne(e=>e.Forms);
          //  entityTypeBuilder.HasMany(e=>e.UserResponse).WithOne(e=>e.Form);

            //entityTypeBuilder.HasOne(e=>e.Questions).WithMany(e=>e.f).HasForeignKey<Question>(t=>t.formId);
        }
    }
}