using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FeebackQuestionaireAPI.Models.EntityMapper
{
    public class UserMapper
    {
        public UserMapper(EntityTypeBuilder<User> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(e=>e.UserId);
            entityTypeBuilder.Property(e=>e.Email);
            entityTypeBuilder.Property(e=>e.UserName);
            
            
        }
    }
}