using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FeebackQuestionaireAPI.Models.EntityMapper
{
    public class UserResponseMapper
    {
        

        public UserResponseMapper(EntityTypeBuilder<UserResponse> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(e=>e.UserRespId);
           // entityTypeBuilder.HasAlternateKey(c => new { c.userId, c.formId });
            //entityTypeBuilder.HasOne(e=>e.Question).WithOne(e=>e.UserResponse).HasForeignKey<Question>(e=>e.QuestId).IsRequired();
          //  entityTypeBuilder.HasOne(e=>e.Users).WithOne(e=>e.UserResponse).HasForeignKey<User>(e=>e.UserId);
           // entityTypeBuilder.HasOne(m => m.UserAnswers).WithOne(m => m.UserResponse).HasForeignKey(e=>e.UserRespId);
        }

        
    }
}