using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FeebackQuestionaireAPI.Models.EntityMapper
{
    public class QuestionMapper
    {
        public QuestionMapper(EntityTypeBuilder<Question> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(e=>e.QuestId);
            entityTypeBuilder.Property(e=>e.QuestionName).IsRequired();
            entityTypeBuilder.HasOne(e=>e.Forms).WithMany(e=>e.Questions).HasForeignKey(e=>e.FormId);
           // entityTypeBuilder.HasOne(e=>e.questiontypes).WithMany(e=>e.Questions).HasForeignKey(e=>e.QuestionTypeId);
        }
    }
}