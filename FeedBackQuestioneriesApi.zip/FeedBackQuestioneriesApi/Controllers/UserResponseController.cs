using System.Net;
using System.Data.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Functionality;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using FeebackQuestionaireAPI.Database;

namespace FeebackQuestionaireAPI.Controllers
{
     [ApiController]
    [Route("[controller]")]
    public class UserResponseController:ControllerBase
    {
        private readonly IUserResponseService userResponseService;
        private readonly IUserAnswer userAnswer;
        private readonly IValidator<UserResponseDto> validator;
        public UserResponseController(IUserResponseService _userResponseService,IUserAnswer _userAnswer,IValidator<UserResponseDto> _validator)
        {
            userAnswer=_userAnswer;
            userResponseService=_userResponseService;
            validator=_validator;
        }
        [HttpPost("Response")]
        public async Task<ActionResult<int>> funcreateResponse(UserResponseDto userResponseDto)
         {
            var formId = await userResponseService.CreateResponse(userResponseDto);
            return Ok(formId);
        }
        [HttpPost("Form/Questin/Answer")]
        public async Task<IActionResult> funcreateAnswers(UserFormResponseDto model)
         {
            //var AnsId = await userAnswer.CreateAnswer(userAnswerDetails,userId,formId);
            return Ok(await userAnswer.SaveUserResponce(model));
        }
        [HttpGet("getAnswerById/{id}")]
        public async Task<ActionResult<UserAnswer>> GetAnswerById(int id)
        {
            var form = await userAnswer.GetFormAnswersByID(id);

            if (form == null)
            {
                return NotFound();
            }

            return Ok(form);
        }
        // [HttpGet("UserResponses")]
        // public async Task<IActionResult> FetchUserResponses()
        // {
        //     return Ok(await userResponseService.GetUserResponses());
        // }
        //  [HttpPost("Form/Questin/Answer")]
        // public async Task<ActionResult<int>> getAnswers(int[] Id)
        //  {
        //     using(UserAnswerDto db = new UserAnswerDto)
        //     {
        //         var result = await db.Questions
        //         .AsEnumerable().Where(y=>Id.Contains(y.FormId))
        //         .OrderBy(x=>{
        //             return Array.IndexOf(Id,x.FormId);
        //         }).Select(z=>z.ans).ToArray();
        //         return this.Request.funcreateResponse(HttpStatusCode.OK,result);
        //     }
        // }
        
    }
}