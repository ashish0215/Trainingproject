using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FluentValidation;

namespace FeebackQuestionaireAPI.Mapper.DTOValidation
{
    public class UserResponsevalidation:AbstractValidator<UserResponseDto>
    {
        public UserResponsevalidation()
        {
            
            RuleFor(UserResponseDTO => UserResponseDTO.FormId);
            RuleFor(UserResponseDTO=>UserResponseDTO.UserId);
        }
    }
  
}