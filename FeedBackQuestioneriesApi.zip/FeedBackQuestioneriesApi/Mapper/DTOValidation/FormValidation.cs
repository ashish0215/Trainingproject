using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FluentValidation;

namespace FeebackQuestionaireAPI.Mapper.DTOValidation
{
    public class FormValidation:AbstractValidator<FormDtO>
    {
        public FormValidation()
        {
            RuleFor(FormDTO => FormDTO.Title).NotEmpty();
            RuleFor(d => d.Description).NotEmpty();
            RuleFor(d => d.PublishedDate).NotEmpty();
            RuleFor(d => d.Submissions).NotEmpty();
            RuleFor(d => d.Link).NotEmpty();
            RuleFor(d => d.ClosedDate).NotEmpty();
            RuleFor(d => d.Status).NotEmpty();
        }
    }
    
}