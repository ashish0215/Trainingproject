using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FluentValidation;

namespace FeebackQuestionaireAPI.Mapper.DTOValidation
{
    public class QuestionTypeValidation:AbstractValidator<QuestionTypeDTO>
    {
        public QuestionTypeValidation()
        {
            RuleFor(QuestionTypeDTO=>QuestionTypeDTO.SingleLineAnswer).NotEmpty();
            RuleFor(QuestionTypeDTO=>QuestionTypeDTO.MultiLineAnswer).NotEmpty();
            RuleFor(QuestionTypeDTO=>QuestionTypeDTO.SingleChoice).NotEmpty();
            RuleFor(QuestionTypeDTO=>QuestionTypeDTO.MultiChoice).NotEmpty();
            RuleFor(QuestionTypeDTO=>QuestionTypeDTO.Ranking).NotEmpty();
            RuleFor(QuestionTypeDTO=>QuestionTypeDTO.Rating).NotEmpty();
        }
    }
    
}