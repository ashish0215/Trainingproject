using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;

namespace FeebackQuestionaireAPI.Mapper.DTO
{
    public class QuestionTypeDTO
    {
        
        public int Type{get;set;}
        public int SingleChoice{get;set;}
        public int MultiChoice{get;set;}
        public int Rating{get;set;}
        public int Ranking{get;set;}
        public string SingleLineAnswer{get;set;}
        public string MultiLineAnswer{get;set;}
        // public QuestionTypes questionType { get; set; }
        //public Question QuesId{get;set;}
        public IList<Question> questions{get;set;}
       
    }
}