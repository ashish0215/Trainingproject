using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;
using static FeebackQuestionaireAPI.Models.Entity.Form;

public class FormDtO
    {
        
        public string Title { get; set; }
        public string Description { get; set; }
        public string Link { get; set; }
        public int Submissions { get; set; }
        public DateTime PublishedDate { get; set; }
        public Status Status { get; set; }
        public DateTime ClosedDate { get; set; }
        public int UserId { get; set; }

        public bool IsDeleted{get;set;}
    }
