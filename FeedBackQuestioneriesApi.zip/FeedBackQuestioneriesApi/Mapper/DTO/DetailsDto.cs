using System.Security.Cryptography.X509Certificates;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FeedBackQuestioneriesApi.Mapper.DTO
{
    public class FormDetailsDTO
    {
        
        public string Title { get; set; }
        public string Description { get; set; }
        public int Submissions { get; set; }
         public int Status { get; set; }
         public int UserId { get; set; }
         
        public IList<QuestionDetailDTO> questionDetailDTO{get;set;}
        public FormDetailsDTO()
        {
            questionDetailDTO = new List<QuestionDetailDTO>();
            
        }
     
        
    
    }

   public class QuestionDetailDTO
   {
      public int TypeId {get;set;}
      public string QuestionName{get;set;}
      
      public IList<OptionDetailDTO> optionDetailDTO{get;set;}
      public IList<UserAnswerDetailDTO> userAnswerDetailDTO{get;set;}
      public QuestionDetailDTO()
      {
        optionDetailDTO = new List<OptionDetailDTO>();
        userAnswerDetailDTO = new List<UserAnswerDetailDTO>();
      }

   }
   public class OptionDetailDTO
   {
        
         public string Option{get;set;}
   }
   public class UserAnswerDetailDTO
   { 
        public string Answer{ get; set; }
        public int QuestionId{get;set;}
       
   }

   public class UserFormResponseDto{
    public int FormId { get; set; }

    public int UserId { get; set; }

    public List<UserAnswerDetailDTO> Responce { get; set; }
   }

}