using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;

namespace FeebackQuestionaireAPI.Mapper.DTO
{
    public class UserResponseDto
    {
         public int UserId{get;set;}
         public int UserRespId{get;set;}
         public int FormId{get;set;}
         
       
      
    }
}