using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;

namespace FeedBackQuestioneriesApi.Mapper.DTO
{
    // public class QuesTypeDTO
    // {
    //     public string questionName { get; set; }
    //     public QuestionTypes questionType { get; set; }
    //   public IList<OptionsDTO> Options { get; set; }
    // }
}