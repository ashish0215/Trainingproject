using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FeebackQuestionaireAPI.Mapper.DTO
{
    public class UserAnswerDto
    {
        
         public int UserAnsId{get;set;} 
        public string Answer { get; set; }
        
        public int QuestionNo { get; set; }
        public int UserRespId{get;set;}//fk
        public UserResponseDto UserResponseDto {get;set;}   //cascading
}
}