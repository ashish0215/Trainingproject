using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore;

namespace FeebackQuestionaireAPI.Functionality
{
    public class QuestionService : IQuestionService
    {
        private readonly FeedbackFormDbContext feedbackDbContext;
        public QuestionService(FeedbackFormDbContext _feedbackDbContext)
        {
            feedbackDbContext = _feedbackDbContext;
        }

        async Task<int> IQuestionService.CreateQuestions(QuestionsDTO questionDTO)
        {
            var Question = new Question(questionDTO);
            feedbackDbContext.Questions.Add(Question);
            await feedbackDbContext.SaveChangesAsync();
            return Question.QuestId;
        }



        int IQuestionService.DeleteQuestion(int id)
        {
            var del = feedbackDbContext.Questions.Find(id);
            feedbackDbContext.Questions.Remove(del);
            return feedbackDbContext.SaveChanges();
        }

        async Task<List<Question>> IQuestionService.GetQuestion()
        {
            return await feedbackDbContext.Questions.ToListAsync();
        }

         public int UpdateForms(QuestionsDTO question)
        {
            var questions = new Question(){
                QuestionName = question.QuestionName,
                QuestId = question.QuesId,
                FormId = question.FormId
                
            };
            
            feedbackDbContext.Questions.Update(questions);
            return feedbackDbContext.SaveChanges();
        }

      
        // int IQuestionService.CreateQuestions(QuestionsDTO questionDTO)
        // {   
        //       var Question = new Question(questionDTO);
        //     {
        //         feedbackDbContext.Questionss.Add(Question);   
        //     }
        //     return feedbackDbContext.SaveChanges();

        // }


        // int IQuestionService.DeleteQuestion(int id)
        // {
        //     var question = feedbackDbContext.Questionss.SingleOrDefault(t => t.QuestId == id);
        //     if (question != null)
        //     {
        //         feedbackDbContext.Remove(question);
        //         return feedbackDbContext.SaveChanges();
        //     }
        //     return -1;
        // }

        // async Task<List<Question>> IQuestionService.GetQuestion()
        // {
        //     // var Questions=await feedbackDbContext.Forms.Include(d=>d.Questions).ToListAsync();
        //     // return Questions;
        //     var questions = await feedbackDbContext.Questionss.Include(a => a.Options).ToListAsync();
        //     return questions;
        // }

        // int IQuestionService.UpdateQuestion(int Id, QuestionsDTO questionsDTO)
        // {
        //     Question Ques = new Question();
        //     Ques= feedbackDbContext.Questionss.SingleOrDefault(t=>t.QuestId==Id);
        //     if(Ques==null)
        //     {
        //         return 0;
        //     }
        //     else
        //     {
        //         Id=0;

        //         Ques.QuestionName = questionsDTO.QuestionName;
        //         Ques.QuestionTypeId=questionsDTO.QuestionTypeId;
        //         Ques.FormId=questionsDTO.FormId;
        //         feedbackDbContext.Questionss.Update(Ques);
        //         Id=Ques.QuestId;
        //         return feedbackDbContext.SaveChanges();

        //     }

        // }
    }
}