using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;

namespace FeebackQuestionaireAPI.Functionality
{
    public interface IUserResponseService
    {
       public Task<int> CreateResponse(UserResponseDto userResponseDto);
        
    }
}