using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;

namespace FeebackQuestionaireAPI.Functionality
{
    public interface IQuestionService
    {
        public Task<int> CreateQuestions(QuestionsDTO questionsDTO);
        
         Task<List<Question>> GetQuestion();
         public int DeleteQuestion(int id);
         public int UpdateForms(QuestionsDTO question);
      
       
    }
}