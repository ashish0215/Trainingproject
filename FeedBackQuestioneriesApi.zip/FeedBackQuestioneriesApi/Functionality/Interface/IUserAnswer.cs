using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;

namespace FeebackQuestionaireAPI.Functionality
{
    public interface IUserAnswer
    {
         public Task<int> CreateAnswer(IList<QuestionAnswer> userAnswerDetails, int userId, int formId);
         Task<List<UserAnswer>> GetFormAnswersByID(int id);
         Task<bool> SaveUserResponce(UserFormResponseDto model);
    
    }
}