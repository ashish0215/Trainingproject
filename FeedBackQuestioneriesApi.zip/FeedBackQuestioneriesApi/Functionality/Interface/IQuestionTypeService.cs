using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;

namespace FeebackQuestionaireAPI.Functionality
{
    public interface IQuestionTypeService
    {
       
    }
}