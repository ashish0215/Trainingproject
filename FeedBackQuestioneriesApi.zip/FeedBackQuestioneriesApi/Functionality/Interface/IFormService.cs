using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;

namespace FeebackQuestionaireAPI.Functionality
{
    public interface IFormService
    {
        public Task<int> CreateForm(FormDetailsDTO formDto);
      
         Task<List<Form>> GetForm();

        public int DeleteForms(int id);
         Task<int> UpdateForm(int Id, FormDetailsDTO formDto);
         
        int EditForm(int id,FormDetailsDTO formDto);
        Task<List<Form>> GetFormByid(int id);
        Task<bool> SaveForm(FormDetailsDTO formDetailsDTO);
    }
}