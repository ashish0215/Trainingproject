using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;

namespace FeebackQuestionaireAPI.Functionality
{
    public class QuestionTypeService : IQuestionTypeService
    {
         private readonly FeedbackFormDbContext feedbackDbContext;
        
        public QuestionTypeService(FeedbackFormDbContext _feedbackDbContext)
        {
            feedbackDbContext=_feedbackDbContext;
        }

        // async Task<int> IQuestionTypeService.CreateTypes(QuestionTypeDTO questiontpedto)
        // {
        //     var questiontype = new QuestionTypes(questiontpedto);
        //     feedbackDbContext.questionTypes.Add(questiontype);
        //     await feedbackDbContext.SaveChangesAsync();
        //     return questiontpedto.QuesTypeId;
        // }
        // object IQuestionTypeService.FetchQuestionType()
        // {
        //     throw new NotImplementedException();
        // }

        // object IQuestionTypeService.FetchQuestionTypeid(int id)
        // {
        //     throw new NotImplementedException();
        // }

        // object IQuestionTypeService.FetchQuestionTypes(int id)
        // {
        //     throw new NotImplementedException();
        // }

        // int IQuestionTypeService.fucCreateQuesType(QuestionTypeDTO quesTypeDto)
        //  {

        //     QuestionTypes questionType = new QuestionTypes();
        //     questionType.MultiChoice= quesTypeDto.MultiChoice;
        //     questionType.MultiLineAnswer=quesTypeDto.MultiLineAnswer;
        //     questionType.Ranking=quesTypeDto.Ranking;
        //     questionType.Rating=quesTypeDto.Rating;
        //     questionType.SingleChoice=quesTypeDto.SingleChoice;
        //     questionType.SingleLineAnswer=quesTypeDto.SingleLineAnswer;
        //     feedbackDbContext.questionTypes.Add(questionType);
        //     return feedbackDbContext.SaveChanges();
        //  }

        // object IQuestionTypeService.GetQuestionTypes(int id)
        // {
        //     throw new NotImplementedException();
        // }
    }
}