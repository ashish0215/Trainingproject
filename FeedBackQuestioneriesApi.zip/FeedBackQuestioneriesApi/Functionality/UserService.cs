using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;

namespace FeebackQuestionaireAPI.Functionality
{
    public class UserService : IUserService
    {
        private readonly FeedbackFormDbContext feedbackDbContext;
        public UserService(FeedbackFormDbContext _feedbackDbContext)
        {
            feedbackDbContext=_feedbackDbContext;
        }

        async Task<int> IUserService.CreateUsers(UserDto userDto)
        {
             var user = new User(userDto);
            feedbackDbContext.Users.Add(user);
            await feedbackDbContext.SaveChangesAsync();
            return user.UserId;
        }

        // int IUserService.funcUsers(UserDto userDto)
        // {
        //     throw new NotImplementedException();
        // }

        // public int funcUsers(UserDto userDto)
        // {
        // try
        // {
        //     feedbackDbContext.Users.Add(user);
        //     return feedbackDbContext.SaveChanges();
        // }
        // catch
        // {
        //     return null;
        // }
        // feedbackDbContext.Users.Add(user);
        // return feedbackDbContext.SaveChanges();



        // User objUser = new User();
        // objUser.UserName = userDto.UserName;
        // objUser.Email=userDto.Email;
        // feedbackDbContext.Users.Add(objUser);
        // return feedbackDbContext.SaveChanges();


    }
    
}