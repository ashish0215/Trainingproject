using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;
using Microsoft.EntityFrameworkCore;

namespace FeebackQuestionaireAPI.Functionality
{
    public class UserAnswerService : IUserAnswer
    {
        private readonly FeedbackFormDbContext feedbackDbContext;
        public UserAnswerService(FeedbackFormDbContext _feedbackDbContext)
        {
            feedbackDbContext=_feedbackDbContext;
        }

        async Task<int> IUserAnswer.CreateAnswer(IList<QuestionAnswer> userAnswerDetails, int userId, int formId)
{
        var answers = userAnswerDetails.Select(a => a.Answer).ToArray();
        var userAns = new UserAnswer((List<QuestionAnswer>)userAnswerDetails, userId, formId);
        feedbackDbContext.userAnswers.Add(userAns);
        await feedbackDbContext.SaveChangesAsync();
        return userAns.UserAnsId;
}

        async Task<List<UserAnswer>> IUserAnswer.GetFormAnswersByID(int id)
        {
           List<UserAnswer> forms = new List<UserAnswer>();
           forms = await feedbackDbContext.userAnswers.Where(f => f.UserAnsId == id).ToListAsync();
           return forms;
        }
        

        public async Task<bool> SaveUserResponce(UserFormResponseDto model){

            foreach(var item in model.Responce){
                UserAnswer domain = new UserAnswer{
                    quesId =item.QuestionId,
                    formId = model.FormId,
                    userId = model.UserId,
                    Answer = item.Answer
                };
                feedbackDbContext.userAnswers.Add(domain);
            }
            await feedbackDbContext.SaveChangesAsync();

            return true;
        }
    }
}