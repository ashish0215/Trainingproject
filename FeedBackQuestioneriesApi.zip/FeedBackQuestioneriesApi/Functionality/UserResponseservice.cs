using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore;

namespace FeebackQuestionaireAPI.Functionality
{
    public class UserResponseservice : IUserResponseService
    {
         private readonly FeedbackFormDbContext feedbackDbContext;
        public UserResponseservice(FeedbackFormDbContext _feedbackDbContext)
        {
            feedbackDbContext=_feedbackDbContext;
        }

        async Task<int> IUserResponseService.CreateResponse(UserResponseDto userResponseDto)
        {
            var questionResponse = new UserResponse(userResponseDto);
            feedbackDbContext.UserResponses.Add(questionResponse);
            await feedbackDbContext.SaveChangesAsync();
            return questionResponse.UserRespId;
        }
     
    }
}