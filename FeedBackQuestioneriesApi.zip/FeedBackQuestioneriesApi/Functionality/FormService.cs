using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;
using Microsoft.EntityFrameworkCore;

namespace FeebackQuestionaireAPI.Functionality
{
    public class FormService : IFormService
    {
        private FeedbackFormDbContext feedbackDbContext;
        public FormService(FeedbackFormDbContext _feedbackDbContext)
        {
            feedbackDbContext = _feedbackDbContext;
        }
        async Task<int> IFormService.CreateForm(FormDetailsDTO formDto)
        {
            var form = new Form(formDto);
            feedbackDbContext.Forms.Add(form);
            await feedbackDbContext.SaveChangesAsync();
            return form.FormId;
        }
        int IFormService.DeleteForms(int id)
        {
            var del = feedbackDbContext.Forms.Find(id);
            del.IsDeleted = true;
            feedbackDbContext.Forms.Remove(del);
            return feedbackDbContext.SaveChanges();
        }

        async Task<List<Form>> IFormService.GetForm()
        {
            return await feedbackDbContext.Forms
            .Where(s => s.IsDeleted == false)
            .OrderByDescending(s => s.FormId)
            .ToListAsync();
        }

        async Task<List<Form>> IFormService.GetFormByid(int id)
        {
            List<Form> forms = new List<Form>();
            forms = await feedbackDbContext.Forms.Include(x => x.Questions).ThenInclude(x => x.Options).Where(f => f.FormId == id).ToListAsync();
            return forms;
        }
        async Task<int> IFormService.UpdateForm(int Id, FormDetailsDTO formDto)
        {


            var entity = await feedbackDbContext.Forms.FindAsync(Id);

            if (entity == null)
            {
                return 0;
            }

            entity.Description = formDto.Description;
            // ...

            feedbackDbContext.Forms.Update(entity);
            await feedbackDbContext.SaveChangesAsync();

            return entity.FormId; // Return the same FormId after saving changes
        }
    

    public async Task<bool> SaveForm(FormDetailsDTO formDetailsDTO)
    {
        var form = new Form(formDetailsDTO);
        feedbackDbContext.Forms.Add(form);
        feedbackDbContext.SaveChanges();
        return true;
    }

    int IFormService.EditForm(int id, FormDetailsDTO formdto)
    {
        Form form = feedbackDbContext.Forms

                                       .Include(u => u.Questions)
                                       .SingleOrDefault(u => u.FormId == id);
        if (form != null)
        {
            form.Title = formdto.Title;
            form.Description = formdto.Description;
            form.Submissions = formdto.Submissions;
            foreach (var questioninfo in formdto.questionDetailDTO)
            {
                Question question = form.Questions.SingleOrDefault(a => a.FormId == questioninfo.TypeId);
                if (question != null)
                {
                    question.QuestionName = questioninfo.QuestionName;

                }
            }


            feedbackDbContext.SaveChanges();
        }
        return 1;
    }



}

}


